<?php
if (!defined('ABSPATH')) exit;

class ITV_Scroll_Widget extends \Elementor\Widget_Base {

    public function get_name() { return 'itv_scroll'; }
    public function get_title() { return 'ITV Scroll List'; }
    public function get_icon() { return 'eicon-menu-bar'; }
    public function get_categories() { return ['general']; }

    protected function register_controls() {

        $this->start_controls_section('content', [
            'label' => 'Items'
        ]);

        $this->add_control(
            'items',
            [
                'label' => 'Items',
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => "NEWS\nGALLERY\nLIVESTREAM",
            ]
        );

        $this->end_controls_section();

        /* STYLE SECTION */
        $this->start_controls_section('style', [
            'label' => 'Text',
            'tab' => \Elementor\Controls_Manager::TAB_STYLE
        ]);

        $this->start_controls_tabs('text_tabs');

        // NORMAL
        $this->start_controls_tab(
            'normal_tab',
            ['label' => 'Normal']
        );

        $this->add_control(
            'text_color_normal',
            [
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} a' => 'color: {{VALUE}} !important;',
                ],
            ]
        );

        $this->end_controls_tab();

        // HOVER
        $this->start_controls_tab(
            'hover_tab',
            ['label' => 'Hover']
        );

        $this->add_control(
            'text_color_hover',
            [
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} a:hover' => 'color: {{VALUE}} !important;',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        $items = explode("\n", $settings['items']);

        echo '<div style="display:flex; gap:20px; overflow-x:auto; white-space:nowrap;">';

        foreach ($items as $item) {
            echo '<a href="#">' . esc_html($item) . '</a>';
        }

        echo '</div>';
    }
}
